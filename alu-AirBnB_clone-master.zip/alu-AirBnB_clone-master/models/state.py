#!/usr/bin/python3
"""documentation"""
from models.base_model import BaseModel


class State(BaseModel):
    """class for state"""
    name = ""
